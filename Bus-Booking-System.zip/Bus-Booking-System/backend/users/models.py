from django.db import models
from django.contrib.postgres.fields import ArrayField

# Two type of users: admin and customer
class User(models.Model):
    username = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    is_admin = models.BooleanField(default=False)

    def __str__(self):
        return self.username

class BusStop(models.Model):
    stop_name = models.CharField(max_length=255)
    latitude = models.FloatField()
    longitude = models.FloatField()

    def __str__(self):
        return self.stop_name
    
class Bus(models.Model):
    bus_name = models.CharField(max_length=255)
    total_seats = models.PositiveIntegerField()
    current_occupancy = models.PositiveIntegerField(default=0)
    available_days = models.DateField()
    bus_route = ArrayField(models.ForeignKey(BusStop, on_delete=models.CASCADE))
    seating_map = ArrayField(models.ForeignKey(User, on_delete=models.SET_NULL, null=True), size=total_seats)

    source = models.ForeignKey(bus_route[0], on_delete=models.CASCADE, related_name="bus_source")
    destination = models.ForeignKey(bus_route[len(bus_route) - 1], on_delete=models.CASCADE, related_name="bus_destination")
    departure_time = models.ArrayField(models.DateTimeField(), size = len(bus_route) - 1)
    arrival_time = models.ArrayField(models.DateTimeField(), size = len(bus_route) - 1)

    def __str__(self):
        return self.bus_name


class Ticket(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    bus = models.ForeignKey(Bus, on_delete=models.CASCADE)
    seat_numbers = models.ArrayField(models.PositiveIntegerField())
    source = models.ForeignKey(BusStop, on_delete=models.CASCADE, related_name="source")
    destination = models.ForeignKey(BusStop, on_delete=models.CASCADE, related_name="destination")
    departure_time = models.DateTimeField()
    arrival_time = models.DateTimeField()
    date_of_booking = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.user.username + " " + self.bus.bus_name + " " + str(self.seat_number) + " " + str(self.date)
    
