from django.contrib import admin
from django.urls import path, include
from . import views

urlpatterns = [
    path("login/", views.login, name="login"),
    path("search_bus/", views.search_bus, name="search_bus"),
    path("booking/", views.booking, name="booking"),
    
]