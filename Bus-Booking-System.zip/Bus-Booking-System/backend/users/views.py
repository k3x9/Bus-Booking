from django.views.decorators.csrf import csrf_protect
from django.http import JsonResponse
from .models import BusStop, User, Bus, Ticket
import json

@csrf_protect
def login(request):
    if request.method == "POST":
        username = request.POST.get("username")
        password = request.POST.get("password")
        if User.objects.filter(username=username).exists():
            user = User.objects.get(username=username)
            if user.password == password:
                return JsonResponse({"status": "success", "is_admin": user.is_admin})
            else:
                return JsonResponse({"status": "failure", "message": "Invalid password"})
        else:
            return JsonResponse({"status": "failure", "message": "Invalid username"})
    else:
        return JsonResponse({"status": "failure", "message": "Invalid request method"})
    
def search_bus(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        source = data['source']
        destination = data['destination']
        date = data['date']
        
        source = BusStop.objects.filter(stop_name=source).first()
        destination = BusStop.objects.filter(stop_name=destination).first()

        if source is None:
            return JsonResponse({"status": "failure", "message": "Sorry no bus stop is available for this source"})
        if destination is None:
            return JsonResponse({"status": "failure", "message": "Sorry no bus stop is available for this destination"})
        
        buses = Bus.objects.filter(bus_route__contains=[source, destination], available_days__contains=date)
        if buses is None:
            return JsonResponse({"status": "failure", "message": "Sorry no bus is available for this route"})
        
        bus_list = []
        for bus in buses:
            bus_list.append({"bus_id": bus.id, "bus_name": bus.bus_name, "total_seats": bus.total_seats, "current_occupancy": bus.current_occupancy, "available_days": bus.available_days, "bus_route": bus.bus_route, "seating_map": bus.seating_map, "source": bus.source, "destination": bus.destination, "departure_time": bus.departure_time, "arrival_time": bus.arrival_time})

        # sort using time taken
        bus_list.sort(key=lambda x: x["departure_time"][0] - x["arrival_time"][len(x["arrival_time"]) - 1])

        return JsonResponse({"status": "success", "bus_list": bus_list})

def booking(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        bus_id = data['bus_id']
        user_id = data['user_id']
        seat_numbers = data['seat_numbers']
        source = data['source']
        destination = data['destination']
        departure_time = data['departure_time']
        arrival_time = data['arrival_time']
        date_of_booking = data['date_of_booking']
        passengers = data['passengers']

        bus = Bus.objects.get(id=bus_id)
        user = User.objects.get(id=user_id)

        if bus is None:
            return JsonResponse({"status": "failure", "message": "Sorry no bus is available for this route"})
        if user is None:
            return JsonResponse({"status": "failure", "message": "Sorry no user is available for this route"})
        
        if bus.current_occupancy + len(seat_numbers) > bus.total_seats:
            return JsonResponse({"status": "failure", "message": "Sorry no seats are available for this bus"})
        
        for seat_number in seat_numbers:
            if bus.seating_map[seat_number] is not None:
                return JsonResponse({"status": "failure", "message": "Sorry this seat is already booked"})
            bus.seating_map[seat_number] = user
        bus.current_occupancy += len(seat_numbers)
        bus.save()

        ticket = Ticket(user=user, bus=bus, seat_numbers=seat_numbers, source=source, destination=destination, departure_time=departure_time, arrival_time=arrival_time, date_of_booking=date_of_booking)
        ticket.save()

        return JsonResponse({"status": "success", "message": "Ticket booked successfully", "ticket_id": ticket.id})
    
def add_bus(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        bus_name = data['bus_name']
        total_seats = data['total_seats']
        current_occupancy = data['current_occupancy']
        available_days = data['available_days']
        bus_route = data['bus_route']
        source = data['source']
        destination = data['destination']

        departure_time = [data['departure_time']]
        arrival_time = []
        # find arrival time using distance between two bus stops using latitute and longitude, and speed of bus as 40 km/hr
        for i in range(1, len(bus_route)):
            distance = ((bus_route[i].latitude - bus_route[i - 1].latitude) ** 2 + (bus_route[i].longitude - bus_route[i - 1].longitude) ** 2) ** 0.5
            time = distance / 40
            arrival_time.append(departure_time[i-1] + time)
            departure_time.append(arrival_time[i-1] + 0.5)
        arrival_time.append(data['arrival_time'])

        bus = Bus(bus_name=bus_name, total_seats=total_seats, current_occupancy=current_occupancy, available_days=available_days, bus_route=bus_route, source=source, destination=destination, departure_time=departure_time, arrival_time=arrival_time)
        bus.save()

        return JsonResponse({"status": "success", "message": "Bus added successfully"})

def add_bus_stop(request):
    if request.method == 'POST':
        data = json.loads(request.body)
        stop_name = data['stop_name']
        latitude = data['latitude']
        longitude = data['longitude']

        bus_stop = BusStop(stop_name=stop_name, latitude=latitude, longitude=longitude)
        bus_stop.save()

        return JsonResponse({"status": "success", "message": "Bus stop added successfully"})
    
